/*
Mi codigo contrutye números y lo que no es un numero lo
almacena en la cadena operadores. Sus principales problemas son:
- Si se ingresa primero un símbolo, el programa falla 
- Si agrega doble símbolo, el programa falla
- Solo puede recibir enteros porque no excluye el punto o las comas
Sin embargo, para fines de la actividad, el programa
se ejecuta en el supuesto de que siempre empieza en números y
que no habrá simbolos juntos o diferentes a "+,-,/ y *"
*/
print("Ingrese una expresión matemática:")
//Usé if let para validar la entrada del usuario 
//y proceder con el resto del código
if let expUsr = readLine() {

    var numeros: [Double] = []
    var operadores: [String] = []
    //Declaré una variable de cadena vacia para llevar la posicion
    //actual y así ir agregando según sea número u operador
    var posActual = ""
    
    for caracter in expUsr {
        //Encontré en stack overflow que se puede usar "_"
        //para ignorar el valor opcional que arroja el cast, porque
        //solo necesito comprobar si es un numero y no guardar innecesariamente la constante
        if let _ = Double(String(caracter)) {
            posActual.append(caracter)
        } else {
            //Una vez que la pocisión actual detecta que no hay un número
            //entra al else y si posActual no esta vacío, agrega el o los números
            //al arreglo numeros
            if !posActual.isEmpty {
                numeros.append(Double(posActual)!)
            //reinicio el arreglo para que vuelva a validar si hay un numero
                posActual = ""
            }
            //Si el caracter no es un espacio, "se supone" que es un
            //operador, en caso de ser un espacio en blanco simplemente avanza de posicion
            //y vuelve a entrar al ciclo
            if caracter != " " {
                operadores.append(String(caracter))
            }
        }
    }
    //Cuando caracter llega a su ultima posición, 
    //se agrega el ultimo numero o cifra del numero
    if !posActual.isEmpty {
        numeros.append(Double(posActual)!)
    }
    
    // El siguiente ciclo es para recorrer los 2 arreglos numeros y operadores
    //se toma un numero, se toma un operador y se valida en switch, se coloca el siguiente
    //numero y se acumula el resultado
    var resultado = numeros[0]
    //Encontré en stack overflow que puedes usar ..< para indicar el
    //límite, en este caso del arreglo. Puse 0 porque es la primera pocisión, y debe de llegar
    //un numero menos del tamaño que arroja .count
    for i in 0..<operadores.count {
        let operador = operadores[i]
        let numero = numeros[i + 1]
        switch operador {
        case "+":
            resultado += numero
        case "-":
            resultado -= numero
        case "*":
            resultado *= numero
        case "/":
            resultado /= numero
        default:
            break
        }
    }
    
    //Finalmente muestro el resultado y las cadenas separadas
    print("Números: \(numeros)")
    print("Operadores: \(operadores)")
    print("Resultado: \(resultado)")
}

import Foundation
//Declaré un booleano para salir de menú, y del ciclo while
var salir = false

func suma(num1: Float, num2: Float) -> Float {
    let resultado = num1 + num2
    return resultado
}

func resta(num1: Float, num2: Float) -> Float {
    let resultado = num1 - num2
    return resultado
}

func mult(num1: Float, num2: Float) -> Float {
    let resultado = num1 * num2
    return resultado
}

func div(num1: Float, num2: Float) -> Float {
    let resultado = num1 / num2
    return resultado
}

//se inicia con !salir, dando el valor de false y que pueda entrar al ciclo
while !salir {
    let resultado: Float
    print("¿Qué operación quieres realizar?\n1. Suma\n2. Resta\n3. Multiplicación\n4. División\n5. Salir")
    /*
    coloqué un if let porque me salía el error "Unexpectedly found nil while unwrapping an Optional value"
    y vi en internet que ocurre cuando vas a desempaquetar un valor opcional y está nulo
    entonces if let, permite vincular la entrada del usuario con una variable opcionalde forma segura
    y despues ya se puede asignar ese valor a otra variable (valor)
    */
    if let opcion = readLine(), let valorOpc = Int(opcion) {
        switch valorOpc {
        case 1:
            print("Ingresa el primer número:")
            if let numero1 = readLine(), let valor1 = Float(numero1) {
                print("Ingresa el segundo número:")
                if let numero2 = readLine(), let valor2 = Float(numero2) {
                    resultado = suma(num1: valor1, num2: valor2)
                    print("El resultado de la suma es: \(resultado)")
                }
            }
        case 2:
            print("Ingresa el primer número:")
            if let numero1 = readLine(), let valor1 = Float(numero1) {
                print("Ingresa el segundo número:")
                if let numero2 = readLine(), let valor2 = Float(numero2) {
                    resultado = resta(num1: valor1, num2: valor2)
                    print("El resultado de la resta es: \(resultado)")
                }
            }
        case 3:
            print("Ingresa el primer número:")
            if let numero1 = readLine(), let valor1 = Float(numero1) {
                print("Ingresa el segundo número:")
                if let numero2 = readLine(), let valor2 = Float(numero2) {
                    resultado = mult(num1: valor1, num2: valor2)
                    print("El resultado de la multiplicación es: \(resultado)")
                }
            }
        case 4:
            print("Ingresa el primer número:")
            if let numero1 = readLine(), let valor1 = Float(numero1) {
                print("Ingresa el segundo número:")
                if let numero2 = readLine(), let valor2 = Float(numero2) {
                    resultado = div(num1: valor1, num2: valor2)
                    print("El resultado de la división es: \(resultado)")
                }
            }
        case 5:
            salir = true
            print("¡Adiós!")
        default:
            print("Opción no válida")
        }
    }
}
